ctlseqs.ms	From the xterm source tree [1].
vttest.tar.gz	From Thomas E. Dickey's site [2].
openi18n/	From the Openi18n web site [3].
rfc/		From the IETF web site [4].

[0] http://www.invisible-island.net/xterm/
[1] ftp://invisible-island.net/xterm/xterm.tar.gz
[2] http://www.invisible-island.net/vttest/vttest.html
[3] http://www.openi18n.org/subgroups/testsuites/interactive/terminal-tests/terminal-emulator-test-scenario.html
[4] http://www.ietf.org/
